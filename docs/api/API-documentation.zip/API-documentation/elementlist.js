
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Gravatar\\Account"],["c","Gravatar\\Hash"],["c","Gravatar\\ProfileRequest"],["c","Gravatar\\Uri"],["c","Gravatar\\XmlProfileRequest"]];
