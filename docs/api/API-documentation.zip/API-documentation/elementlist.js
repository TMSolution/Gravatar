
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Gravatar\\AbstractRequest"],["c","Gravatar\\Account"],["c","Gravatar\\Hash"],["c","Gravatar\\ImageRequest"],["c","Gravatar\\JsonProfileRequest"],["c","Gravatar\\ProfileRequest"],["c","Gravatar\\QrProfileRequest"],["c","Gravatar\\Response"],["c","Gravatar\\Uri"],["c","Gravatar\\VcfProfileRequest"],["c","Gravatar\\XmlProfileRequest"]];
